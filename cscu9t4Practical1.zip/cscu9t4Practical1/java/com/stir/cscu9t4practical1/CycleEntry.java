package com.stir.cscu9t4practical1;

public class CycleEntry extends Entry{
	
	private string terrain;
	private string tempo;
	
	 public Entry (String n, int d, int m, int y, int h, int min, int s, float dist, string terrain,string tempo )
	{
		 super (n,d,m,y,h,min,s,dist)
		 this.terrain= terrain;
		 this.tempo= tempo; 	 
	}

	 public String getterrain () 
	 {
		    return terrain;
	 }
	 
	 public String gettempo ()
	 {
		    return tempo;
	 } 
	 public String getEntry () {
		   String result = getName()+" ran " + getDistance() + " km in "
		             +getHour()+":"+getMin()+":"+ getSec() + " on "
		             +getDay()+"/"+getMonth()+"/"+getYear()+"\n";
		   return result;
		  } 
		   
		} 
	 